# Common file for avoiding circular import.

def admin_bot():
    from AdminBot.bot import bot as admin_bot
    return admin_bot


def user_bot():
    from UserBot.bot import bot as user_bot
    return user_bot
